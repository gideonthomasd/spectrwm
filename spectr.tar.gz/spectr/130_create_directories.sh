#!/bin/bash


if [ ! -d $HOME"/.config" ] 
then mkdir -p $HOME"/.config"
fi

if [ ! -d $HOME"/.config/spectrwm" ]
then
mkdir -p $HOME"/.config/spectrwm"
fi

if [ ! -d $HOME"/.config/termite" ]
then
mkdir -p $HOME"/.config/termite"
fi

if [ ! -d $HOME"/.config/rofi" ] 
then
mkdir -p $HOME"/.config/rofi"
fi

if [ ! -d $HOME"/.config/jgmenu" ]
then
mkdir -p $HOME"/.config/jgmenu"
fi

if [ ! -d $HOME"/.config/polybar" ]
then
mkdir -p $HOME"/.config/polybar"
fi



cp -Rf ~/.config ~/.config-backup-$(date +%Y.%m.%d-%H.%M.%S)

cd spectrwm
cp -r * ~/.config/spectrwm
cd ..


cd termite
cp -r * ~/.config/termite
cd ..

cd rofi
cp -r * ~/.config/rofi
cd ..

cd jgmenu
cp -r * ~/.config/jgmenu
cd ..

cd polybar
cp -r * ~/.config/polybar
cd ..

cp spectrwm.conf ~/.spectrwm.conf

mv ~/.bashrc ~/.bashrc-$(date +%Y.%m.%d-%H.%M.%S)
cp bashrc ~/.bashrc



git clone  https://github.com/salman-abedin/devour.git
cd devour
sudo make install
echo "All done"
cd ..
echo "Go to dwm6-2 and do sudo make install"


#cp -arf bspwm ~/.config/bspwm
#cp -arf sxhkd ~/.config/sxhkd
#cp -arf polybar ~/.config/polybar

#cd test2
#cd bspwm
#cp -r * ~/mythetest
#cd ..
#cd ..
#pwd
