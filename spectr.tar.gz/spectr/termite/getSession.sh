#!/bin/bash

sleep 10s
dwm='DESKTOP_SESSION="dwm"'
process=$(export | grep DESKTOP | awk 'NR==1 {print $3}') 
if [ $process = $dwm ]
then
setxkbmap gb &
# Keyboard

killall lxpolkit &
killall dwm_bar.sh &
killall testwallpaper &
killall xcompmgr &
killall sxhkdrc &
sleep 1s
lxpolkit &
/home/phil/dwm-bar/dwm_bar.sh &

#xrandr --output Virtual-1 --mode 1920x1080 &

/home/phil/.dwm/testwallpaper &

xcompmgr -o 0.5 & 
sxhkd -c /home/phil/dwm-6.2/sxhkdrc &
else
	echo "hi" > out
fi
