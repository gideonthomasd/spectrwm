/home/phil/dwm-bar/dwm_bar.sh &
# Keyboard
setxkbmap gb &
lxpolkit &

# Display
#xrandr --output Virtual-1 --mode 1920x1080 &
#nitrogen --restore &
#variety &
/home/phil/.dwm/testwallpaper &
#picom  --config $HOME/.config/picom/picom.conf &
xcompmgr -c &

# Loop


#exec dwm

