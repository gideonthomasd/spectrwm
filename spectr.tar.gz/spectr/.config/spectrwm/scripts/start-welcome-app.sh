#!/bin/bash
/usr/bin/dex ~/.config/autostart/arcolinux-welcome-app.desktop &
