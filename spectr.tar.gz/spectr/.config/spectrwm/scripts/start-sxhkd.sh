#!/bin/bash
/usr/bin/sxhkd -c ~/.config/spectrwm/sxhkd/sxhkdrc &
