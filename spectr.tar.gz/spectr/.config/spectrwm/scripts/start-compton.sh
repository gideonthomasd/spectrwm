#!/bin/bash
/usr/bin/picom --config ~/.config/spectrwm/picom.conf &
